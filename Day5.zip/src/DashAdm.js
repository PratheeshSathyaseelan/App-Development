import React from 'react';
import PodcastEpisode from './PodcastEpisode'; 
import './DashAdm.css'; 
import Taskbar from './Taskbar';
import Top from './Top';
import images from './Images/images.avif'

const episodes = [
 
  
];

function DashAdm() {
 
  return (
    <div>
      <div className='task'>
      <Taskbar /> {/* Include the Taskbar component */}
      </div>
      <div className='top'>
        <Top/>
      </div>
      <div className="dashboard">
      <h1>Kids Storytelling Podcast</h1>
      <div className="episode-list">
        {episodes.map((episode) => (
          <PodcastEpisode key={episode.id} episode={episode} />
        ))}
        <button className='samupdate'>Update</button>
        <button className='samdelete'>Delete</button>
      </div>
    </div>
    </div>
  );
}

export default DashAdm;
