import React from 'react';
import Login from './Login';
import SignupPage from './SignupPage';
import PodcastEpisodeS from './PodcastEpisode';
import DashboardPage from './DashboardPage';
import { BrowserRouter, Route } from 'react-router-dom';
import { Routes } from 'react-router-dom';
import AdminLogin from './AdminLogin';
import DashAdm from './DashAdm';

function App() {
  
  return (
    <div className="App">
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Login/>}></Route>
      <Route path='/signup' element={<SignupPage/>}></Route>
      <Route path='/dash' element={<DashboardPage/>}></Route>
      <Route path='/admin' element={<AdminLogin/>}></Route>
      <Route path='/addash' element={<DashAdm/>}></Route>
    </Routes>
    </BrowserRouter>
  </div>
  );
}

export default App;
