import React from 'react';
import PodcastEpisode from './PodcastEpisode'; 
import './Dashboard.css'; 
import Taskbar from './Taskbar';
import Top from './Top';
import images from './Images/images.avif'

const episodes = [
  {
    id: 1,
    title: 'The Adventure Begins',
    description: 'Join us on a magical journey through the enchanted forest.',
    audioUrl: 'audio/episode1.mp3',
    imageUrl: 'https://image.smythstoys.com/zoom/205722_3.jpg',
  },
  {
    id: 2,
    title: 'The Lost Treasure',
    description: 'Captain Jack and his crew search for buried treasure.',
    audioUrl: 'audio/episode2.mp3',
    imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRWKzvVzHlY0ptFxulYco-LNso6r_4fgdcUrQ&usqp=CAU',
  },
  {
    id: 3,
    title: 'The Secret Garden',
    description: 'Discover the hidden wonders of the secret garden.',
    audioUrl: 'audio/episode3.mp3', 
    imageUrl: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmAvWzupUeFIPkx61O5rU2keD9R4UPlLt-YBZgvrEKCmfjsKVls0HZkDOWzRnznn7tuts&usqp=CAU', 
  },
  {
    id: 4,
    title: 'Dora Bujji',
    description: 'Travel with Dora.',
    audioUrl: 'audio/episode3.mp3', 
    imageUrl: 'https://i.playboard.app/p/c313a0177f6a16b825de0129ac4b4b63/default.jpg', 
  },
  {
    id: 5,
    title: 'When do hippos play',
    description: 'When do hippos play.',
    audioUrl: 'audio/episode3.mp3', 
    imageUrl: 'https://images.squarespace-cdn.com/content/v1/5493706de4b0ecaa4047b871/1d6ebd3f-333f-4a58-830f-9d834d6d3956/When+Do+Hippos+Play+Cover+Small+Thumbnail.jpeg', 
  },
  {
    id: 6,
    title: 'The lion and the mouse',
    description: 'Story about the lion and mouse.',
    audioUrl: 'audio/episode3.mp3', 
    imageUrl: 'https://chimesradio.com/wp-content/uploads/2021/11/Lion-and-mouse-1024x1024.jpeg', 
  },
  
  
];

function DashboardPage() {
 
  return (
    <div>
      <div className='task'>
      <Taskbar /> 
      </div>
      <div className='top'>
        <Top/>
      </div>
      <div className="dashboard">
      <h1>Kids Storytelling Podcast</h1>
      <div className="episode-list">
        {episodes.map((episode) => (
          <PodcastEpisode key={episode.id} episode={episode} />
        ))}
      </div>
    </div>
    </div>
  );
}

export default DashboardPage;
