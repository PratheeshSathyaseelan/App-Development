import React, { useState, useEffect } from 'react';
import './Slideshow.css';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';

const Slideshow = ({ images, interval }) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, interval);

    return () => {
      clearInterval(timer);
    };
  }, [images, interval]);

  const goToPrev = () => {
    setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  const goToNext = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  return (
    <div className="slideshow">
      <img src={images[currentIndex]} alt="Slideshow" />
      <div className="navigation">
        <NavigateBeforeIcon style={{ fontSize: '40px' }} onClick={goToPrev} className="prev" />
        <NavigateNextIcon style={{ fontSize: '40px' }} onClick={goToNext} className="next" />
      </div>
    </div>
  );
};

export default Slideshow;
