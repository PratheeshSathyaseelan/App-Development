// ItemList.js

import React, { useState } from 'react';
import './ItemList.css'

function ItemList() {
  const items = ['Item 1', 'Item 2', 'Item 3'];
  const [favorites, setFavorites] = useState([]);

  const handleFavoriteClick = (item) => {
    if (favorites.includes(item)) {
      // Item is already a favorite, so remove it
      setFavorites(favorites.filter((favorite) => favorite !== item));
    } else {
      // Add the item to favorites
      setFavorites([...favorites, item]);
    }

    // Store the updated favorites in local storage
    localStorage.setItem('favorites', JSON.stringify(favorites));
  };

  return (
    <div>
      <h1>Item List</h1>
      <ul>
        {items.map((item, index) => (
          <li key={index}>
            {item}
            <button onClick={() => handleFavoriteClick(item)}>
              {favorites.includes(item) ? 'Unfavorite' : 'Favorite'}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ItemList;
