package com.example.demo.enumerate;

public enum Role {

	USER, ADMIN
}
